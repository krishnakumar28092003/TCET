package comtcet;
import java.util.*;
public class question5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] crates= {0,1,0,3,12,0,5};
		moveZerosToEnd(crates);
		System.out.println("creates after moving empty crates to the end: "+Arrays.toString(crates));
		public static void moveZerosToEnd(int[] crates) {
			int j=0;
			for(int i=0;i<crates.length;i++)
			{
				if(crates[i]!=0) {
					int temp=crates[i];
					crates[i]=crates[j];
					crates[j]=temp;
					j++;
					
				}
			}
		
		}
	

		
	}
}


