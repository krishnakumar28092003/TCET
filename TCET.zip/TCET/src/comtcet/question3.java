//import java.util.*;



package comtcet;
import java.util.*;

public class question3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.print("Enter a string:");
		String input=s.nextLine();
		s.close();
		input.toLowerCase();
		input=input.replace("[^a-zA-Z0-9\\s]","");
		HashMap<String,Integer> wordcount=new HashMap<>();
		for(String word:words)
		

	}

}
