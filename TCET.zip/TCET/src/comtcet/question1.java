package comtcet;

@FunctionalInterface
interface Sayable{
	String say(String message);
}

public class question1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sayable sayable=(message)-> "hello, "+message+"!";
		String greeting=sayable.say("john");
		System.out.println(greeting);
		
	}

}
