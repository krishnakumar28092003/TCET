package comtcet;
class NumberPrinter implements Runnable{
	@Override
	public void run() {
		for(int i=1;i<=5;i++) {
			System.out.print(i);
			try {
				Thread.sleep(500);
			}catch(InterruptedException e) {
				System.out.print("Thread interrupted");
			}
		}
	}
}

public class question2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NumberPrinter numberPrinter=new NumberPrinter();
		Thread thread=new Thread(numberPrinter);
		thread.start();

	}

}
