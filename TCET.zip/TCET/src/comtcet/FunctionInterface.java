package comtcet;

public @interface FunctionInterface {

}
